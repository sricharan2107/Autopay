/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Auto_DriverDb;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class Auto_Driver extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String s1,s2;
       response.setContentType("text/html");
        PrintWriter out=response.getWriter();
       s1=request.getParameter("nd");
       s2=request.getParameter("passd");
       Auto_DriverDb n=new Auto_DriverDb();
       int k=n.Success(s1,s2);
       String roll = n.chimpanzee();
       if(k!=0)
       {
           out.println("<html>");
           out.println("<body>");
           out.println("<form action=\"TransDrv\" method=\"post\">\n" +
"            <input type=\"hidden\" name=\"usern\" value = " + roll + ">\n" +
        
"            <button>Trans</button>\n" +
"        </form>");
           out.println("</body>");
           out.println("</html>");
       }
       else
       {
           RequestDispatcher rd=request.getRequestDispatcher("/driverfail.html");
           rd.forward(request, response);
       }
    }

}
