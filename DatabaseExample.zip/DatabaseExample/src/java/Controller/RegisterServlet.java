/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.RegisterDb;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SRIRAJARAJESWARI
 */
public class RegisterServlet extends HttpServlet {

    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String s1,s2,s3,s4;
       s1=request.getParameter("n");
       s2=request.getParameter("r");
       s3=request.getParameter("p");
       s4=request.getParameter("cp");
       RegisterDb n=new RegisterDb();
       int k=n.Success(s1,s2,s3,s4);
        //System.out.println(k);
       if(k!=0)
       {
           RequestDispatcher rd=request.getRequestDispatcher("/success.jsp");
           rd.forward(request, response);
       }
       else
       {
           //System.out.println(k);
           RequestDispatcher rd=request.getRequestDispatcher("/error.jsp");
           rd.forward(request, response);
       }
    }

    
}
