/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.TransDb;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class Trans extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String s1;
       response.setContentType("text/html");
            PrintWriter out=response.getWriter();
       s1=request.getParameter("usern");
       TransDb n=new TransDb();
       System.out.println(s1);
       ResultSet rs = n.Success(s1);
       out.println("<html>");
             out.println("<body>");
                out.println("<table border = 1px>");
                out.println("<tr>\n" +
"                <td>Sno</td>\n" +
"                <td>Initial amount</td>\n" +
"                <td>autoId</td>\n" +
"                <td>amount deducted</td>\n" +
"                <td>available amount</td>\n" +
"            </tr>");
                System.out.println("hello"+rs);
                try{
                while(rs.next())
                {
                    
                    out.println("<tr>\n" +
"                <td>" + Integer.parseInt(rs.getString(1)) + "</td>\n" +
"                <td>" + Integer.parseInt(rs.getString(2)) + "</td>\n" +
"                <td>" + rs.getString(3) + "</td>\n" +
"                <td>" + Integer.parseInt(rs.getString(4)) + "</td>\n" +
"                <td>" + Integer.parseInt(rs.getString(4)) + "</td>\n" +
"            </tr>");
                }
                out.println("</table>");
                out.println("</body>");
                out.println("</html>");
                }
                 catch(Exception e)
                {
                e.printStackTrace();
                }
                
       }
}
