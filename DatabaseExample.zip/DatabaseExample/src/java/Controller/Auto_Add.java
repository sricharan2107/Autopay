/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Auto_AddDb;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class Auto_Add extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String s1,s2;
       s1=request.getParameter("nd");
       s2=request.getParameter("passd");
       Auto_AddDb n=new Auto_AddDb();
       int k=n.Success(s1,s2);
       if(k!=0)
       {
           RequestDispatcher rd=request.getRequestDispatcher("/success.jsp");
           rd.forward(request, response);
       }
       else
       {
           //System.out.println(k);
           RequestDispatcher rd=request.getRequestDispatcher("/error.jsp");
           rd.forward(request, response);
       }
    }

}
