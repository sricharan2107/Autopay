/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Dec_AutoDb;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class Dec_Auto extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
       String s1,s2;
       int j=0;
       s1=request.getParameter("usern");
       s2=request.getParameter("auton");
       Dec_AutoDb n=new Dec_AutoDb();
       System.out.println(s1 + " " + s2);
       int[] k=n.Success(s1,s2);
       int m=n.payment();
       if(k[0]!=0 && k[2]!=0)
       {
           out.println("<html>");
           out.println("<body>");
           //HttpSession s=request.getSession();
           //s.setAttribute("amount", m);
           //RequestDispatcher rd=request.getRequestDispatcher("/loginsuccess.");
           //rd.forward(request, response);
           out.println("Your Payment Was SuccessFull.<br>");
           out.println("You Spend today is"+m);
           out.println("</body>");
           out.println("</html>");
       }
       else
       {
           out.println("<html>");
           out.println("<body>");
           out.println("Your Payment is not SuccessFull.<br>");
           out.println("your current balance is insufficient or invaild autoID");
           out.println("</body>");
           out.println("</html>");
       }
    }
       
}
