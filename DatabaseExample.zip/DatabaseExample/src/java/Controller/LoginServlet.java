/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.LoginDb;
import Model.RegisterDb;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String s1,s2;
       response.setContentType("text/html");
        PrintWriter out=response.getWriter();
       s1=request.getParameter("nuse");
       s2=request.getParameter("passuse");
       LoginDb n=new LoginDb();
       int k=n.Success(s1,s2);
       String roll = n.chimpanzee();
       System.out.println(k);
       if(k!=0)
       {
           out.println("<html>");
           out.println("<body>");
           out.println("<form action=\"Dec_Auto\" method=\"post\">\n" +
"            <input type=\"hidden\" name=\"usern\" value = " + roll + ">\n" +
        
"            <input type=\"text\" name=\"auton\" placeholder=\"Enter autoID\">\n" +
"            <button>submit</button>\n" +
"        </form>");
           out.println("<form action=\"Trans\" method=\"post\">\n" +
"            <input type=\"hidden\" name=\"usern\" value = " + roll + ">\n" +
        
"            <button>Trans</button>\n" +
"        </form>");
           out.println("</body>");
           out.println("</html>");
           
           //RequestDispatcher rd=request.getRequestDispatcher("/loignsuccess.html");
           //rd.forward(request, response);
       }
       else
       {
           RequestDispatcher rd=request.getRequestDispatcher("/loginfail.html");
           rd.forward(request, response);
       }
    }

    
}
