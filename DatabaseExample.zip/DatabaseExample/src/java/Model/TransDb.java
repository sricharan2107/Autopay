/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class TransDb extends HttpServlet {

    int sno,initial,amt,curr;
    String auto;
    ResultSet rs;
    HttpServletResponse response;
    public ResultSet Success(String s1) {
       try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/autog","root","");
            Statement st=con.createStatement();
           // String quer="select * from user_info";
            boolean flag = true;
            
            //String query="insert into user_info values('"+s1+"','"+s2+"','"+s3+"')";
            System.out.println(s1);
            String disp = "SELECT * from "+s1;
            rs = st.executeQuery(disp);
            System.out.println("hfuui"+rs);
            /*while(rs.next())
            {
                System.out.println(rs.getString(1));
                out.println("<tr>\n" +
"                <td>" + Integer.parseInt(rs.getString(1)) + "</td>\n" +
"                <td>" + Integer.parseInt(rs.getString(2)) + "</td>\n" +
"                <td>" + rs.getString(3) + "</td>\n" +
"                <td>" + Integer.parseInt(rs.getString(4)) + "</td>\n" +
"                <td>" + Integer.parseInt(rs.getString(4)) + "</td>\n" +
"            </tr>");
                
                
            }*/
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
       return rs;
    }
    
}
