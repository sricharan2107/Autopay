/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class AddMUserDb extends HttpServlet {

    int k=0;
    int sno,curr_bal,initial_bal;
    String auto_p;
    public int Success(String s1, String s2) {
       try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/autog","root","");
            Statement st=con.createStatement();
           // String quer="select * from user_info";
            boolean flag = true;
            
            //String query="insert into user_info values('"+s1+"','"+s2+"','"+s3+"')";
            String disp = "SELECT * FROM "+s2;
            ResultSet rs = st.executeQuery(disp);
            while(rs.next())
            {
                //String id = rs.getString(1);
                sno = Integer.parseInt(rs.getString(1));
                initial_bal = Integer.parseInt(rs.getString(2));
                auto_p = rs.getString(3);
                curr_bal = Integer.parseInt(rs.getString(2));
                initial_bal = Integer.parseInt(rs.getString(3));
                
            }
            sno += 1;
            curr_bal += Integer.parseInt(s1);
            String q = "insert into " + s2 + " values(" + sno + "," + initial_bal + "'0',0," + curr_bal + ")" ;
            st.executeUpdate(q);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return k;
    }

}
