/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class Auto_RemoveDb extends HttpServlet {

     int k=0;
    String id, name;
    public int Success(String s1) {
       try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/autog","root","");
            Statement st=con.createStatement();
           // String quer="select * from user_info";
            boolean flag = true;
            
            //String query="insert into user_info values('"+s1+"','"+s2+"','"+s3+"')";
            String disp = "SELECT id FROM auto_info";
            ResultSet rs = st.executeQuery(disp);
            while(rs.next())
            {
                String id = rs.getString(1);

                if(id.equals(s1))
                {
                    flag = false;break;
                }
            }
            System.out.println(flag);
            if(!flag){
                String query = "DROP TABLE "+s1;
                st.executeUpdate(query);
                String q2 = "DELETE FROM auto_info WHERE id='"+s1+"'";
                k=st.executeUpdate(q2);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return k;
    }

}
