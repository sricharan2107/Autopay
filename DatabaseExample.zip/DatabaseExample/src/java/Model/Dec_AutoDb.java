/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class Dec_AutoDb extends HttpServlet {
    
    int k=0,k1=0;
    int initial_bal=0,sno,curr_amt=0, cost=20,initial_bala=0,snoa,curr_amta=0;
    public static boolean autoCheck(String s1)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/autog","root","");
            Statement st=con.createStatement();
            String q = "Select id from auto_info";
                ResultSet rs = st.executeQuery(q);
                while (rs.next())
                {
                    if (rs.getString(1).equals(s1))
                        return true;
                }

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }
    
    public static boolean userCheck(String s1)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/autog","root","");
            Statement st=con.createStatement();
            String q = "Select rollno from user_info";
                ResultSet rs = st.executeQuery(q);
                while (rs.next())
                {
                    if (rs.getString(1).equals(s1))
                        return true;
                }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return false;

    }
    
    public int[] Success(String s1, String s2) {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/autog","root","");
            Statement st=con.createStatement();
            
            if (autoCheck(s2) && userCheck(s1))
            {
                
                System.out.println(s1 + " " + s2 + "yeahhhhhhhhh");
                String q1 = "SELECT sno,curr_bal FROM "+s1;
                ResultSet rs = st.executeQuery(q1);
                
                while(rs.next())
                {
                    //System.out.println("whileeee");

                    initial_bal = Integer.parseInt(rs.getString(2));
                    sno=Integer.parseInt(rs.getString(1));
                }
                
                if (initial_bal >= cost)
                {
                System.out.println("ifff");

                    curr_amt = initial_bal - cost;
                    sno += 1;
                    String query = "Insert into "+s1+" values("+sno+","+initial_bal+",'"+s2+"',"+cost+","+curr_amt+")";
                    k=st.executeUpdate(query);
                 }
                String q2 = "SELECT sno,curr_bal FROM "+s2;
                ResultSet rs2 = st.executeQuery(q2);
                
                while(rs2.next())
                {
                    initial_bala = Integer.parseInt(rs2.getString(2));
                    snoa =Integer.parseInt(rs2.getString(1));
                }
                
                curr_amta = initial_bala + cost;
                snoa += 1;
                String query1 = "Insert into "+s2+" values("+snoa+","+initial_bala+",'"+s1+"',"+cost+","+curr_amta+")";
                k1=st.executeUpdate(query1);

            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        int arr[] = new int[3];
        arr[0] = k;
        arr[2] = k1;
        arr[1] = initial_bal;
        return arr;
    }

    public int payment() {
        return cost;
    }

}
