/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SRIRAJARAJESWARI
 */
public class RegisterDb {
    int k;
    public int Success(String s1, String s2,String s3,String s4) {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/autog","root","");
            Statement st=con.createStatement();
           // String quer="select * from user_info";
            boolean flag = true;
            
            //String query="insert into user_info values('"+s1+"','"+s2+"','"+s3+"')";
            String disp = "SELECT rollno FROM user_info";
            ResultSet rs = st.executeQuery(disp);
            while(rs.next())
            {
                String roll = rs.getString(1);
                if(roll.equals(s2))
                {
                    flag = false;break;
                }
            }
            //System.out.println(s1+" "+s2+" "+s3+" "+s4);
            if(flag){
                String query = "insert into user_info values('"+s1+"','"+s2+"','"+s3+"')";
                String query2 = "create table "+s2+" (sno int,intial_bal int,auto_p varchar(20),amt_p int,curr_bal int)";
                st.executeUpdate(query2);
                String q3 = "insert into "+s2+" values(1,100,0,0,100)";
                st.executeUpdate(q3);
                k=st.executeUpdate(query);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return k;
    }
    
}
