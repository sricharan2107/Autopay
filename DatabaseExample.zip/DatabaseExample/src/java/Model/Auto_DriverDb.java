/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class Auto_DriverDb extends HttpServlet {

    int k=0;
    String roll, name;
    public int Success(String s1, String s2) {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/autog","root","");
            Statement st=con.createStatement();
            
           // String quer="select * from user_info";
           boolean flag = false;
            String disp = "SELECT id,pass FROM auto_info";
            ResultSet rs = st.executeQuery(disp);
            while(rs.next())
            {
                roll = rs.getString(1);
                //System.out.println(roll);
                name= rs.getString(2);
                    
                if(s1.equals(roll) && s2.equals(name)){
                    k++;
                    break;
                }
            }
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return k;
    }
    public String chimpanzee(){
        return roll;
    }
}
