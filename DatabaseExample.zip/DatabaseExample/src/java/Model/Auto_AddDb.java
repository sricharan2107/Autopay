/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vivek
 */
public class Auto_AddDb extends HttpServlet {

    int k=0;
    String id, name;
    public int Success(String s1, String s2) {
       try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/autog","root","");
            Statement st=con.createStatement();
           // String quer="select * from user_info";
            boolean flag = true;
            
            //String query="insert into user_info values('"+s1+"','"+s2+"','"+s3+"')";
            String disp = "SELECT id FROM auto_info";
            ResultSet rs = st.executeQuery(disp);
            while(rs.next())
            {
                String id = rs.getString(1);
                if(id.equals(s1))
                {
                    flag = false;break;
                }
            }
            //System.out.println(s1+" "+s2+" "+s3+" "+s4);
            if(flag){
                String query = "insert into auto_info values('"+s1+"','"+s2+"')";
                String query2 = "create table "+s1+" (sno int,intial_bal int,user_p varchar(20),amt_p int,curr_bal int)";
                st.executeUpdate(query2);
                String q3 = "insert into "+s1+" values(0,0,0,0,0)";
                st.executeUpdate(q3);
                k=st.executeUpdate(query);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return k;
    }
        
}
