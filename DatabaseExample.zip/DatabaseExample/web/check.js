function check(){
var name= document.forms["regis"]["n"].value;
var roll=document.forms["regis"]["r"].value;
var password=document.forms["regis"]["p"].value;
var confirm=document.forms["regis"]["cp"].value;

if(name="")
alert("Please enter the name ");
}